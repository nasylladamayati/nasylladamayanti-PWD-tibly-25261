# pertemuan-05

saya bernama: Yohanes Setiawan Japriadi<br>
NIM: 0344300002<br>
Kelompok: TI1A<br>
<br>
Hari ini, Rabu 22.Oktober.2025, saya belajar:
<ol>
  <li>copy index.html dan style.css folder pertemuan-04</li>
  <li>tombol hamburger</li>
  <li>class menu-toggle</li>
  <li>class menu-toggle mobile</li>
  <li>styling nav mobile</li>
  <li>styling nav menu mobile</li>
  <li>membuat script.js</li>
</ol>